<?php echo $__env->make('Admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--
`body` tag options:

  Apply one or more of the following classes to to the body tag
  to get the desired effect

  * sidebar-collapse
  * sidebar-mini
-->
<body class="hold-transition sidebar-mini">
<div class="wrapper">


    <?php if(\Illuminate\Support\Facades\Auth::check()): ?>

    <?php echo $__env->make('Admin.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>


    <!-- Main Footer -->




</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

  <?php echo $__env->make('Admin.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\admin\meldingen-nl-admin\resources\views/Admin.blade.php ENDPATH**/ ?>